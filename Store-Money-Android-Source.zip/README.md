# Store Money Android starter

Premium dark-blue native Android starter (Kotlin).

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync finish (Android SDK Platform 35 and build tools may be requested).
4. Select **Build > Build APK(s)**.
5. Find the APK under `app/build/outputs/apk/debug/`.

## Current status
This is a UI starter, not a real-money wallet and not a compiled APK. Buttons show informational placeholder screens. It has no live balance, payment processing, QR payment validation, bank payout, or authentication backend.

## Before real-money use
Use an RBI-authorized bank/payment/wallet provider and its official integration. Implement server-side authentication, transaction verification, idempotency, audit logs, fraud controls, and secure secrets management. Do not put provider secrets in the Android app. Provider eligibility/age/KYC rules must be followed; ask a parent/guardian to handle setup where legally required.
