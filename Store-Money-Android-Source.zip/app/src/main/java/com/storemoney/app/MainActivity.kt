package com.storemoney.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val navy = Color.rgb(8, 17, 43)
    private val blue = Color.rgb(35, 104, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 180, 210)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun bg(view: android.view.View, color: Int, radius: Float = 22f) {
        val d = GradientDrawable(); d.setColor(color); d.cornerRadius = radius
        view.background = d
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD }
    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text=label; setTextColor(white); setBackgroundColor(blue); setOnClickListener { action() } }
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(24,32,24,24); setBackgroundColor(navy)
    }
    private fun showHome() {
        val root=base()
        root.addView(text("STORE MONEY",22f,white,true))
        root.addView(text("Your money, your control",14f,muted))
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,24) }
        bg(card,Color.rgb(20,37,79),26f)
        card.addView(text("WALLET BALANCE",13f,muted))
        card.addView(text("₹ 0.00",34f,white,true))
        card.addView(text("Real payments: connect an authorized provider",12f,muted))
        root.addView(card,LinearLayout.LayoutParams(-1,190).apply { topMargin=28; bottomMargin=20 })
        root.addView(button("Deposit / Add money") { info("Deposit", "Connect an authorized UPI/payment provider to receive real funds.") })
        root.addView(button("Withdraw / Bank transfer") { info("Withdraw", "Bank payouts require a verified provider, eligible account, and server-side checks.") })
        root.addView(button("Scan QR") { info("QR Scanner", "QR scanning UI placeholder. Add a camera/ML Kit scanner and trusted payment validation.") })
        root.addView(button("Transaction history") { info("History", "Your transactions will appear here after secure backend integration.") })
        root.addView(button("Login / Signup") { info("Account", "Add secure authentication through your backend. Never store passwords in this app.") })
        root.addView(text("\nSECURITY NOTE\nThis starter app does not hold or move money. Balance is display-only until a compliant backend/provider is integrated.",13f,muted))
        setContentView(root)
    }
    private fun info(title: String, message: String) {
        val root=base(); root.addView(text(title,24f,white,true)); root.addView(text("\n$message",16f,muted))
        root.addView(button("Back to Store Money") { showHome() }); setContentView(root)
    }
}
